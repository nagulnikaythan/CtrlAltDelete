from flask import Flask, render_template, request, redirect, session, flash, jsonify
import pickle
import os
import csv
import random

# ================= LIVEKIT CONFIG =================
LIVEKIT_API_KEY = "WkfG8Q9hy6kCMORtXhJwVRZ8pZuGHd35sDx1W7uufFN"        # <-- paste here later
LIVEKIT_API_SECRET = "APIZQdQg3jVJQiV"    # <-- paste here later
LIVEKIT_URL = "wss://edtech-voice-ai-5zv20qc7.livekit.cloud"           # <-- paste here later

app = Flask(__name__)
app.secret_key = "edubridge_secret_key"

# ---------------- FILE PATHS ----------------
USER_FILE = "users.dat"
MARKS_FILE = "marks.csv"

# ---------------- INITIALIZE FILE ----------------
if not os.path.exists(USER_FILE):
    with open(USER_FILE, "wb") as f:
        pickle.dump([], f)

# ---------------- INITIALIZE MARKS FILE ----------------
if not os.path.exists(MARKS_FILE):
    with open(MARKS_FILE, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["email", "subject", "exam", "marks"])


# ---------------- HELPERS ----------------
def load_users():
    with open(USER_FILE, "rb") as f:
        return pickle.load(f)

def save_users(users):
    with open(USER_FILE, "wb") as f:
        pickle.dump(users, f)

def generate_roll(name, phone):
    prefix = name[:2].upper()
    suffix = phone[-2:]
    rand = random.randint(10, 99)
    return f"{prefix}{suffix}{rand}"

def get_marks_for_student(email):
    records = []

    if not os.path.exists(MARKS_FILE):
        return records

    with open(MARKS_FILE, newline="") as f:
        reader = csv.DictReader(f)

        for row in reader:
            if row.get("email") != email:
                continue

            try:
                records.append({
                    "subject": row["subject"],
                    "exam": row["exam"],
                    "marks": int(row["marks"])
                })
            except (ValueError, TypeError):
                continue

    return records


# def add_mark(email, subject, exam, marks):
#     with open(MARKS_FILE, "a", newline="") as f:
#         writer = csv.writer(f)
#         writer.writerow([
#             email.strip(),
#             subject.strip(),
#             exam.strip(),
#             int(marks)
#         ])

def add_mark(email, subject, exam, marks):
    with open(MARKS_FILE, "a", newline="") as f:
        writer = csv.writer(f)
        writer.writerow([email, subject, exam, int(marks)])



def get_teachers():
    return [u for u in load_users() if u.get("role") == "teacher"]

def get_class_average(student_class, section):
    if not os.path.exists(MARKS_FILE):
        return None

    total = 0
    count = 0

    with open(MARKS_FILE, newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if (
                row.get("class") == student_class
                and row.get("section") == section
            ):
                try:
                    total += int(row["marks"])
                    count += 1
                except:
                    pass

    return round(total / count, 2) if count else None


def process_voice_query(user_email, role, query):
    query = query.lower()

    users = load_users()

    # ---------------- BASIC USER INFO ----------------
    if "my name" in query:
        for u in users:
            if u.get("email") == user_email:
                return f"Your name is {u.get('name')}."

    if "my class" in query:
        for u in users:
            if u.get("email") == user_email:
                return f"You are in class {u.get('class')} section {u.get('section')}."

    # ---------------- STUDENT MARKS ----------------
    if "my marks" in query or "my result" in query:
        marks = get_marks_for_student(user_email)
        if not marks:
            return "Your marks have not been published yet."

        response = "Here are your marks. "
        for m in marks:
            response += f"{m['subject']} in {m['exam']} is {m['marks']}. "
        return response

    # ---------------- CLASS AVERAGE (TEACHER) ----------------
    if role == "teacher" and "class average" in query:
        parts = query.split()
        try:
            class_index = parts.index("class")
            student_class = parts[class_index + 1]
            section = parts[class_index + 2].upper()

            avg = get_class_average(student_class, section)
            if avg is None:
                return f"No marks available for class {student_class} section {section}."

            return f"The class average of class {student_class} section {section} is {avg}."

        except:
            return "Please specify class and section correctly."

    return "Sorry, I could not understand your request."

def get_ai_context_summary():
    users = load_users()

    students = []
    teachers = []

    for u in users:
        if u.get("role") == "student":
            students.append({
                "name": u.get("name"),
                "email": u.get("email"),
                "class": u.get("class"),
                "section": u.get("section")
            })

        elif u.get("role") == "teacher":
            teachers.append({
                "name": u.get("name"),
                "email": u.get("email"),
                "department": u.get("department")
            })

    marks = []
    if os.path.exists(MARKS_FILE):
        with open(MARKS_FILE, newline="") as f:
            reader = csv.DictReader(f)
            for row in reader:
                marks.append({
                    "email": row["email"],
                    "subject": row["subject"],
                    "exam": row["exam"],
                    "marks": row["marks"]
                })

    return {
        "students": students,
        "teachers": teachers,
        "marks": marks
    }


# ---------------- ROUTES ----------------
@app.route("/")
def root():
    return redirect("/login")

@app.route("/api/voice-assistant", methods=["POST"])
def voice_assistant():
    if "email" not in session:
        return jsonify({"reply": "Unauthorized"}), 401

    data = request.json
    query = data.get("query", "")

    response = process_voice_query(
        user_email=session.get("email"),
        role=session.get("role"),
        query=query
    )

    return jsonify({"reply": response})


# ================= STUDENT =================
@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        for u in load_users():
            if u.get("email") == email and u.get("password") == password and u.get("role") == "student":
                session["user"] = u["name"]
                session["email"] = u["email"]
                session["role"] = "student"
                return redirect("/dashboard")

        flash("Invalid student credentials")
        return redirect("/login")

    return render_template("login.html")

@app.route("/signup", methods=["GET", "POST"])
def signup():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        phone = request.form["phone"]
        
        password = request.form["password"]
        # PASSWORD LENGTH CHECK
        if len(password) < 8:
            flash("Password must be at least 8 characters long")
            return redirect("/signup")

        
        student_class = request.form["class"]
        section = request.form["section"]
        section = section.upper()


        # EMAIL CHECK
        if "@" not in email:
            flash("Enter a valid Email")
            return redirect("/signup")

        # PHONE CHECK
        if not phone.isdigit() or len(phone) != 10:
            flash("Phone number must be exactly 10 digits")
            return redirect("/signup")

        # CLASS CHECK (NEW CONSTRAINT)
        if not student_class.isdigit() or not (1 <= int(student_class) <= 12):
            flash("Enter a valid class (1–12)")
            return redirect("/signup")

        users = load_users()
        for u in users:
            if u.get("email") == email:
                flash("Account already exists")
                return redirect("/signup")

        users.append({
            "name": name,
            "email": email,
            "phone": phone,
            "password": password,
            "class": student_class,
            "section": section.upper(),
            "role": "student",
            "roll": generate_roll(name, phone)
        })

        save_users(users)
        flash("Student account created successfully")
        return redirect("/login")

    return render_template("signup.html")


@app.route("/doubtdesk", methods=["GET", "POST"])
def doubtdesk():
    if session.get("role") != "student":
        return redirect("/login")

    users = load_users()
    teachers = [u for u in users if u.get("role") == "teacher"]

    chat = None

    # ---------------- POST: send message ----------------
    if request.method == "POST":
        selected_teacher_email = request.form.get("teacher_email")
        message_text = request.form.get("feedback")

        for u in users:
            if u.get("email") == selected_teacher_email and u.get("role") == "teacher":

                if "doubt_chats" not in u:
                    u["doubt_chats"] = []

                # Find existing chat for this student
                for c in u["doubt_chats"]:
                    if c["student_email"] == session["email"]:
                        chat = c
                        break

                # Create new chat if not exists
                if not chat:
                    chat = {
                        "student_name": session["user"],
                        "student_email": session["email"],
                        "messages": []
                    }
                    u["doubt_chats"].append(chat)

                # Append student message
                chat["messages"].append({
                    "sender": "student",
                    "text": message_text
                })

                save_users(users)

                # Redirect with correct GET parameter
                return redirect(f"/doubtdesk?teacher_email={selected_teacher_email}")

    # ---------------- GET: load chat ----------------
    selected_teacher_email = request.args.get("teacher_email")

    if selected_teacher_email:
        for u in users:
            if (
                u.get("email") == selected_teacher_email
                and u.get("role") == "teacher"
                and "doubt_chats" in u
            ):
                for c in u["doubt_chats"]:
                    if c["student_email"] == session["email"]:
                        chat = c
                        break

    return render_template(
        "doubtdesk.html",
        teachers=teachers,
        chat=chat,
        selected_teacher=selected_teacher_email
    )



# ================= TEACHER =================
@app.route("/logint", methods=["GET", "POST"])
def logint():
    if request.method == "POST":
        email = request.form["email"]
        password = request.form["password"]

        for u in load_users():
            if u.get("email") == email and u.get("password") == password and u.get("role") == "teacher":
                session["user"] = u["name"]
                session["email"] = u["email"]
                session["role"] = "teacher"
                return redirect("/home")

        flash("Invalid teacher credentials")
        return redirect("/logint")

    return render_template("logint.html")

@app.route("/signupt", methods=["GET", "POST"])
def signupt():
    if request.method == "POST":
        name = request.form["name"]
        email = request.form["email"]
        phone = request.form["phone"]
        
        password = request.form["password"]
        
        # PASSWORD LENGTH CHECK
        if len(password) < 8:
            flash("Password must be at least 8 characters long")
            return redirect("/signupt")

        department = request.form["department"]

        if "@" not in email:
            flash("Enter a valid Email")
            return redirect("/signupt")

        users = load_users()
        for u in users:
            if u.get("email") == email:
                flash("Account already exists")
                return redirect("/signupt")

        users.append({
            "name": name,
            "email": email,
            "phone": phone,
            "password": password,
            "role": "teacher",
            "department": department
        })

        save_users(users)
        flash("Teacher account created successfully")
        return redirect("/logint")

    return render_template("signupt.html")

@app.route("/teacher/marks", methods=["GET", "POST"])
def teacher_marks():
    if session.get("role") != "teacher":
        return redirect("/logint")

    users = load_users()
    teacher_email = session.get("email")

    # ---------------- GET TEACHER DEPARTMENT ----------------
    teacher_department = None
    for u in users:
        if u.get("email") == teacher_email and u.get("role") == "teacher":
            teacher_department = u.get("department")
            break

    if not teacher_department:
        flash("Teacher department not found")
        return redirect("/home")

    # ---------------- FILTERS ----------------
    selected_class = request.args.get("class")
    selected_section = request.args.get("section")

    students = [
        u for u in users
        if u.get("role") == "student"
        and (not selected_class or u.get("class") == selected_class)
        and (not selected_section or u.get("section") == selected_section)
    ]

    classes = sorted(set(
        u["class"] for u in users
        if u.get("role") == "student" and u.get("class")
    ))

    sections = sorted(set(
        u["section"] for u in users
        if u.get("role") == "student" and u.get("section")
    ))

    # ---------------- SAVE MARKS ----------------
    if request.method == "POST":
        student_email = request.form.get("student_email")
        exam = request.form.get("exam")
        marks = request.form.get("marks")

        subject = teacher_department  # 🔒 SUBJECT LOCKED

        try:
            marks = int(marks)
            if not (0 <= marks <= 100):
                raise ValueError
        except ValueError:
            flash("Marks must be between 0 and 100")
            return redirect(request.referrer)

        add_mark(student_email, subject, exam, marks)

        flash(f"{subject} marks added successfully")
        return redirect(request.referrer)

    return render_template(
        "marks.html",
        students=students,
        classes=classes,
        sections=sections,
        selected_class=selected_class,
        selected_section=selected_section,
        teacher_department=teacher_department
    )


@app.route("/ai-tools")
def ai_tools():
    if session.get("role") != "teacher":
        return redirect("/logint")
    return render_template("ai_tools.html")


@app.route("/teacher/ai-tools")
def teacher_ai_tools():
    if session.get("role") != "teacher":
        return redirect("/logint")
    return render_template("ai_tools.html")


# ================= DASHBOARDS =================
@app.route("/dashboard")
def dashboard():
    if session.get("role") != "student":
        return redirect("/login")

    marks_data = get_marks_for_student(session["email"])

    return render_template(
        "dashboard.html",
        username=session["user"],
        marks_data=marks_data
    )


@app.route("/home")
def teacher_home():
    if session.get("role") != "teacher":
        return redirect("/logint")
    return render_template("home.html")

@app.route("/teacher/doubts", methods=["GET", "POST"])
def teacher_doubts():
    if session.get("role") != "teacher":
        return redirect("/logint")

    users = load_users()
    teacher_email = session.get("email")

    doubt_chats = []
    chat = None

    # Find logged-in teacher
    for u in users:
        if u.get("email") == teacher_email and u.get("role") == "teacher":
            doubt_chats = u.get("doubt_chats", [])

            # ---------------- POST: teacher reply ----------------
            if request.method == "POST":
                student_email = request.form.get("student_email")
                reply_text = request.form.get("reply")

                for c in doubt_chats:
                    if c["student_email"] == student_email:
                        c["messages"].append({
                            "sender": "teacher",
                            "text": reply_text
                        })
                        save_users(users)
                        return redirect(f"/teacher/doubts?student_email={student_email}")

            # ---------------- GET: load selected chat ----------------
            selected_student = request.args.get("student_email")
            if selected_student:
                for c in doubt_chats:
                    if c["student_email"] == selected_student:
                        chat = c
                        break

            break

    return render_template(
        "teacher_doubts.html",
        doubt_chats=doubt_chats,
        chat=chat,
        selected_student=request.args.get("student_email")
    )

@app.route("/teacher/student/<email>")
def teacher_view_student(email):
    if session.get("role") != "teacher":
        return redirect("/logint")

    for u in load_users():
        if u.get("email") == email and u.get("role") == "student":
            return render_template("student_profile_view.html", user=u)

    flash("Student not found")
    return redirect("/teacher/students")


@app.route("/teacher/students")
def teacher_students():
    if session.get("role") != "teacher":
        return redirect("/logint")

    users = load_users()

    selected_class = request.args.get("class")
    selected_section = request.args.get("section")

    # FILTER STUDENTS
    students = []
    for u in users:
        if u.get("role") != "student":
            continue
        if not u.get("class") or not u.get("section"):
            continue
        if selected_class and u.get("class") != selected_class:
            continue
        if selected_section and u.get("section") != selected_section:
            continue
        students.append(u)

    # UNIQUE CLASSES & SECTIONS FOR FILTERS
    classes = sorted(set(
        u["class"] for u in users
        if u.get("role") == "student" and u.get("class")
    ))

    sections = sorted(set(
        u["section"] for u in users
        if u.get("role") == "student" and u.get("section")
    ))

    return render_template(
        "students.html",
        students=students,
        classes=classes,
        sections=sections,
        selected_class=selected_class,
        selected_section=selected_section
    )



# ================= PROFILE =================
@app.route("/profile")
def profile():
    if session.get("role") != "student":
        return redirect("/login")

    for u in load_users():
        if u.get("email") == session.get("email"):
            return render_template("profile.html", user=u)

    return redirect("/dashboard")


@app.route("/update_profile", methods=["POST"])
def update_profile():
    if session.get("role") != "student":
        return redirect("/login")

    users = load_users()
    session_email = session.get("email")

    for u in users:
        if u.get("email") == session_email:
            u["name"] = request.form["name"]
            u["phone"] = request.form["phone"]
            u["password"] = request.form["password"]

            # ❌ EMAIL IS NEVER MODIFIED
            # u["email"] = ...

            session["user"] = u["name"]
            break

    save_users(users)
    flash("Profile updated successfully")
    return redirect("/profile")


# ================= ASSISTANCE =================
@app.route("/assistance")
def assistance():
    if session.get("role") != "student":
        return redirect("/login")
    return render_template("assistance.html")

@app.route("/api/chat", methods=["POST"])
def api_chat():
    role = session.get("role")

    # Allow both teacher & student
    if role not in ["student", "teacher"]:
        return jsonify({"reply": "Unauthorized"}), 401

    raw_message = request.json.get("message", "")
    user_message = raw_message.lower()

    user_name = session.get("user", "User")
    user_email = session.get("email")

    reply = None   # 🔑 fallback trigger

    # ================= PREDEFINED LOCAL LOGIC =================

    if "my name" in user_message:
        reply = f"Your name is {user_name}."

    elif "who am i" in user_message:
        reply = f"You are logged in as a {role}."

    elif "my marks" in user_message and role == "student":
        records = get_marks_for_student(user_email)
        if records:
            lines = [
                f"{r['subject']} ({r['exam']}): {r['marks']} marks"
                for r in records
            ]
            reply = "Here are your marks:\n" + " | ".join(lines)
        else:
            reply = "Your marks have not been published yet."

    # ================= FALLBACK TO AI =================
    if reply is None:
        try:
            from openai import OpenAI
            theapi=open("YOURAPI.txt","r")
            api_key = theapi.read()
            theapi.close()
            client = OpenAI(api_key=api_key)

            context_data = get_ai_context_summary()

            system_prompt = f"""
You are an AI assistant for a school management system.

User details:
- Name: {user_name}
- Role: {role}
- Email: {user_email}

Rules:
- Use ONLY the provided data if the question is related.
- If the question is NOT related to the data, say politely that it is not applicable.
- Never invent data.
- Keep answers clear and professional.
- End responses politely.
- Slight autocorrection for exmaple, if the user says glasses you can assume it to be classes according to the school context and anwer accoringly 
Backend Data:
Students: {context_data['students']}
Teachers: {context_data['teachers']}
Marks: {context_data['marks']}

The user is asking:
"{raw_message}"

If relevant, answer using the data.
If not relevent try checking weather the user's question is under the CBSE syllabus or JEE,Neet or something educational if so then reply with concise answer for that
If not, reply appropriately with a short explanation and a thank you.

"""

            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": raw_message}
                ]
            )

            reply = response.choices[0].message.content

        except Exception as e:
            reply = "You have to create your own API key from https://platform.openai.com/api-keys  \n After creation paste it in the YOUR_API.txt \nThank you."

    return jsonify({"reply": reply})


# ================= RESOURCES =================
@app.route("/resources")
def resources():
    if session.get("role") != "student":
        return redirect("/login")
    return render_template("resources.html")

# ================= LOGOUT =================
@app.route("/logout")
def logout():
    session.clear()
    return redirect("/login")

# ---------------- RUN ----------------
if __name__ == "__main__":
    print("Starting EduBridge server...")
    # Change host to 0.0.0.0 for Docker compatibility
    app.run(host="0.0.0.0", port=8000, debug=True, use_reloader=False)
